
declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
  }
}

/**
 * Tracks a standard or custom event for Facebook Pixel.
 * This function checks if the Facebook Pixel is loaded before attempting to track an event.
 * @param eventName The name of the event to track (e.g., 'InitiateCheckout', 'Purchase').
 * @param options Additional data to send with the event.
 */
export const trackFBevent = (eventName: string, options: object = {}) => {
  if (typeof window.fbq === 'function') {
    window.fbq('track', eventName, options);
  } else {
    console.warn(`Facebook Pixel not loaded. Could not track event: ${eventName}`);
  }
};
