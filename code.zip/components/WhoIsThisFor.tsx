
import React from 'react';
import { motion } from 'framer-motion';
import { Check, X, Briefcase, GraduationCap, User, Building, PenSquare, BarChart } from 'lucide-react';

const whoIsFor = [
  { icon: Briefcase, text: 'Karyawan' },
  { icon: GraduationCap, text: 'Mahasiswa' },
  { icon: User, text: 'Freelancer' },
  { icon: Building, text: 'Pengusaha' },
  { icon: PenSquare, text: 'Content Creator' },
  { icon: BarChart, text: 'Digital Marketer' },
];

const WhoIsThisFor: React.FC = () => {
  return (
    <section id="target-audience" className="py-20 sm:py-28 bg-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
              Ebook Ini Didesain Khusus Buat Lo yang...
            </h2>
            <p className="mt-4 text-lg text-brand-gray">
              ...ingin berhenti jadi pengguna 'biasa' dan mulai jadi 'master' AI untuk melejitkan karir dan produktivitas.
            </p>
            <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-6">
              {whoIsFor.map((item, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <item.icon className="w-6 h-6 text-brand-blue" />
                  <span className="text-brand-light font-medium">{item.text}</span>
                </div>
              ))}
            </div>
          </motion.div>
          <motion.div
            className="bg-brand-dark p-8 rounded-xl border border-brand-dark-secondary"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.7 }}
          >
            <h3 className="text-2xl font-bold text-brand-yellow flex items-center">
              <X className="w-7 h-7 mr-3 text-red-500" />
              Bukan Untuk Lo yang...
            </h3>
            <ul className="mt-6 space-y-4 text-brand-gray list-inside">
              <li className="flex items-start"><X className="w-5 h-5 mr-2 mt-1 text-red-500 flex-shrink-0" /><span>Puas dengan hasil biasa-biasa aja.</span></li>
              <li className="flex items-start"><X className="w-5 h-5 mr-2 mt-1 text-red-500 flex-shrink-0" /><span>Malas belajar hal baru untuk maju.</span></li>
              <li className="flex items-start"><X className="w-5 h-5 mr-2 mt-1 text-red-500 flex-shrink-0" /><span>Mencari tombol ajaib tanpa mau usaha.</span></li>
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default WhoIsThisFor;
