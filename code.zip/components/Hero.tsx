
import React from 'react';
import { motion } from 'framer-motion';
import { trackFBevent } from '../utils/facebookPixel';

const Hero: React.FC = () => {
  const handleCTAClick = () => {
    trackFBevent('InitiateCheckout', {
      content_name: 'Ebook: 23 Teknik Nge-Hack ChatGPT',
      currency: 'IDR',
      value: 99000,
    });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-brand-dark pt-24 pb-12 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(56,189,248,0.1)_0%,_transparent_50%)]"></div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="text-center lg:text-left"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-brand-light">
              Stop Dapet Jawaban <span className="text-brand-yellow">Ngaco</span> dari ChatGPT.
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-brand-gray max-w-2xl mx-auto lg:mx-0">
              Bongkar <span className="font-bold text-brand-light">23 teknik rahasia</span> yang mengubah AI jadi Asisten Jenius pribadi lo. Bikin kerjaan kelar lebih cepat & buat lo selangkah di depan.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#pricing"
                onClick={handleCTAClick}
                className="bg-brand-blue hover:bg-sky-400 text-brand-dark font-bold text-lg py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 button-glow w-full sm:w-auto"
              >
                YA, SAYA MAU EBOOKNYA!
              </a>
            </div>
            <p className="mt-4 text-sm text-brand-gray">
              Penawaran Terbatas! <span className="font-bold text-white">Diskon 70%</span> Hari Ini.
            </p>
          </motion.div>
          <motion.div
            className="flex justify-center items-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="animate-float relative">
              <img 
                src="https://storage.googleapis.com/aai-web-samples/prompt-gallery/23-teknik-nge-hack-chatgpt-cover.png" 
                alt="Ebook Cover: 23 Teknik Nge-Hack ChatGPT" 
                className="w-auto h-96 lg:h-[28rem] rounded-lg shadow-2xl shadow-brand-blue/20"
                width="384"
                height="512"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
