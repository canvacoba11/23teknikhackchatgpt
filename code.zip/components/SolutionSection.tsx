
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Zap, BrainCircuit, Rocket } from 'lucide-react';

const benefits = [
  {
    icon: Zap,
    title: "Perintah Sekali Jalan",
    description: "Gak perlu lagi ngulang-ngulang, sekali kasih prompt hasilnya langsung 'nendang' dan sesuai kemauan lo."
  },
  {
    icon: BrainCircuit,
    title: "AI Jadi 'Nurut Total'",
    description: "Ubah ChatGPT dari mesin penjawab jadi asisten pribadi jenius yang ngertiin lo setengah kata."
  },
  {
    icon: Rocket,
    title: "Naikkan Produktivitas",
    description: "Selesaikan tugas lebih cepat, lebih baik, dan bikin lo diliat sebagai 'problem solver' andalan di tim."
  }
];

const SolutionSection: React.FC = () => {
  return (
    <section id="solution" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
            Ini Bukan Buku Teori. <span className="text-brand-blue text-glow">Ini Jalan Pintas Lo.</span>
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Lupakan cara lama yang bikin frustrasi. Ebook ini adalah kumpulan 'cheat code' praktis yang bisa langsung lo pakai.
          </p>
        </div>
        <div className="mt-16 max-w-4xl mx-auto">
          <div className="bg-brand-dark-secondary rounded-xl p-8 md:p-12 border border-brand-dark-secondary">
            <h3 className="text-2xl font-bold text-center text-brand-light mb-8">Dengan ebook ini, lo bakal bisa:</h3>
            <div className="space-y-8">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={index}
                  className="flex items-start md:items-center space-x-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ delay: index * 0.2 }}
                >
                  <div className="flex-shrink-0 bg-brand-blue/10 p-3 rounded-full">
                    <benefit.icon className="h-7 w-7 text-brand-blue" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl text-brand-light">{benefit.title}</h4>
                    <p className="text-brand-gray mt-1">{benefit.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;
