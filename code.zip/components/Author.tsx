
import React from 'react';
import { motion } from 'framer-motion';
import { UserCircle } from 'lucide-react';

const Author: React.FC = () => {
  return (
    <section id="author" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="max-w-4xl mx-auto bg-brand-dark-secondary rounded-xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 md:gap-12 border border-brand-dark-secondary"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7 }}
        >
          <div className="flex-shrink-0">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-brand-dark flex items-center justify-center border-4 border-brand-blue">
              <UserCircle className="w-24 h-24 text-brand-gray" />
            </div>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-brand-light">Dari Siapa Lo Belajar?</h2>
            <p className="mt-2 text-xl font-semibold text-brand-blue">Mada Wafa</p>
            <p className="mt-4 text-brand-gray">
              Mada adalah seorang praktisi teknologi yang frustrasi dengan jawaban 'standar' dari AI. Dia mendedikasikan ratusan jam untuk 'nge-hack' ChatGPT, mencari celah, dan menemukan pola-pola yang tidak banyak orang tahu.
              <br/><br/>
              Buku ini adalah rangkuman dari semua eksperimen, kegagalan, dan 'Aha!' momennya. Semua rahasianya kini dibagikan ke lo dalam format yang gampang dicerna dan langsung bisa dipraktekkan.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Author;
