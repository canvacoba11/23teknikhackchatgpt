
import React from 'react';
import { motion } from 'framer-motion';
import { Gift, FileText, MessageSquare } from 'lucide-react';

const bonuses = [
  {
    icon: FileText,
    title: "Kumpulan 50+ Prompt Siap Pakai",
    description: "Template prompt untuk berbagai profesi (marketing, coding, nulis, dll) yang bisa langsung lo copy-paste.",
    value: "150.000"
  },
  {
    icon: MessageSquare,
    title: "Akses Grup Telegram Eksklusif",
    description: "Join komunitas untuk diskusi, tanya jawab, dan dapat update teknik terbaru langsung dari penulis.",
    value: "100.000"
  }
];

const Bonus: React.FC = () => {
  return (
    <section id="bonus" className="py-20 sm:py-28 bg-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <Gift className="mx-auto h-12 w-12 text-brand-yellow" />
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-brand-light">
            Tunggu, Ada Lagi! Beli Hari Ini & Dapatkan...
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Bonus Spesial ini hanya untuk kamu yang ambil tindakan cepat. Total nilai <span className="font-bold text-white">Rp 250.000</span>, GRATIS!
          </p>
        </div>
        <div className="mt-16 max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
          {bonuses.map((bonus, index) => (
            <motion.div
              key={index}
              className="bg-brand-dark p-8 rounded-xl border border-dashed border-brand-yellow/50 flex items-start space-x-5"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ delay: index * 0.2 }}
            >
              <div className="flex-shrink-0">
                <bonus.icon className="w-10 h-10 text-brand-yellow" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-brand-light">{bonus.title}</h3>
                <p className="mt-2 text-brand-gray">{bonus.description}</p>
                <p className="mt-3 text-sm font-semibold text-brand-yellow">Senilai: Rp {bonus.value}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Bonus;
