
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Code, Megaphone, PenTool } from 'lucide-react';
import { testimonials } from '../constants';

const Testimonials: React.FC = () => {
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <section id="testimonials" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
            Kata Mereka yang Udah <span className="text-brand-blue text-glow">'Naik Level'</span>
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Ini bukan cuma omongan gue. Mereka udah buktiin sendiri.
          </p>
        </div>
        <motion.div
          className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              className="bg-brand-dark-secondary p-8 rounded-xl flex flex-col border border-transparent hover:border-brand-yellow transition-colors duration-300"
              variants={itemVariants}
            >
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-brand-yellow fill-current" />
                ))}
              </div>
              <p className="text-brand-light flex-grow">"{testimonial.quote}"</p>
              <div className="mt-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-brand-dark flex items-center justify-center mr-4">
                  {testimonial.icon === 'Code' && <Code className="w-6 h-6 text-brand-blue" />}
                  {testimonial.icon === 'Megaphone' && <Megaphone className="w-6 h-6 text-brand-blue" />}
                  {testimonial.icon === 'PenTool' && <PenTool className="w-6 h-6 text-brand-blue" />}
                </div>
                <div>
                  <p className="font-bold text-brand-light">{testimonial.name}</p>
                  <p className="text-sm text-brand-gray">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
