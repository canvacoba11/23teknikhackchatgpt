
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { faqs } from '../constants';

interface FAQItemProps {
  faq: {
    question: string;
    answer: string;
  };
  expanded: boolean;
  setExpanded: (expanded: boolean) => void;
}

const FAQItem: React.FC<FAQItemProps> = ({ faq, expanded, setExpanded }) => {
  const isOpen = expanded;

  return (
    <div className="border-b border-brand-dark-secondary">
      <motion.header
        initial={false}
        onClick={() => setExpanded(!isOpen)}
        className="flex justify-between items-center py-5 cursor-pointer"
      >
        <h3 className="font-semibold text-brand-light text-lg">{faq.question}</h3>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="w-6 h-6 text-brand-gray" />
        </motion.div>
      </motion.header>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.section
            key="content"
            initial="collapsed"
            animate="open"
            exit="collapsed"
            variants={{
              open: { opacity: 1, height: 'auto' },
              collapsed: { opacity: 0, height: 0 },
            }}
            transition={{ duration: 0.4, ease: [0.04, 0.62, 0.23, 0.98] }}
          >
            <div className="pb-5 text-brand-gray">{faq.answer}</div>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
};

const FAQ: React.FC = () => {
  const [expanded, setExpanded] = useState<false | number>(0);

  return (
    <section id="faq" className="py-20 sm:py-28 bg-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
            Masih Ragu? Cek Pertanyaan Ini.
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Kami jawab semua keraguan lo di sini.
          </p>
        </div>
        <div className="mt-16 max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              faq={faq}
              expanded={expanded === index}
              setExpanded={() => setExpanded(expanded === index ? false : index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
