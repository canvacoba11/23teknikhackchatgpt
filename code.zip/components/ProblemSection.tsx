
import React from 'react';
import { motion } from 'framer-motion';
import { Frown, Clock, Users, TrendingDown } from 'lucide-react';

const painPoints = [
  {
    icon: Frown,
    text: "Hasil ChatGPT kaku, 'gitu-gitu aja', dan sering gak 'ngeh' sama maunya lo.",
  },
  {
    icon: Clock,
    text: 'Habisin waktu berjam-jam cuma buat revisi & benerin hasil kerjaan AI.',
  },
  {
    icon: Users,
    text: "Liat temen atau kolega kok kayaknya jago banget pake AI, jadi minder & ngerasa ketinggalan.",
  },
  {
    icon: TrendingDown,
    text: 'Khawatir karir mentok karena gak bisa manfaatin teknologi AI yang makin canggih.',
  },
];

const ProblemSection: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="problem" className="py-20 sm:py-28 bg-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
            Lo Ngerasa <span className="text-brand-yellow">Gini Juga</span> Gak, Bro?
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Kalau jawaban lo 'iya' untuk salah satu poin di bawah, tenang... lo gak sendirian.
          </p>
        </div>
        <motion.div
          className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {painPoints.map((point, index) => (
            <motion.div
              key={index}
              className="flex items-start space-x-4 p-6 bg-brand-dark rounded-xl border border-brand-dark-secondary hover:border-brand-blue transition-colors duration-300"
              variants={itemVariants}
            >
              <div className="flex-shrink-0">
                <point.icon className="h-8 w-8 text-brand-blue" />
              </div>
              <p className="text-brand-light text-lg">{point.text}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default ProblemSection;
