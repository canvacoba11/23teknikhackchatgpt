
import React from 'react';
import { Zap } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-dark border-t border-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-brand-gray">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Zap className="text-brand-yellow h-6 w-6" />
          <span className="text-xl font-bold text-brand-light">Tech.Mada</span>
        </div>
        <p className="text-sm">
          &copy; {currentYear} Tech.Mada. All rights reserved.
        </p>
        <p className="text-xs mt-2">
          Sebuah produk digital untuk membantu Anda menjadi jenius di era AI.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
