
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Zap } from 'lucide-react';
import { trackFBevent } from '../utils/facebookPixel';

const Pricing: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ hours: 1, minutes: 23, seconds: 45 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 0, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (time: number) => time.toString().padStart(2, '0');

  const handlePurchaseClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    trackFBevent('InitiateCheckout', {
      content_name: 'Ebook: 23 Teknik Nge-Hack ChatGPT',
      currency: 'IDR',
      value: 99000,
    });
    // In a real app, this would redirect to a payment gateway.
    // For example: window.location.href = 'https://your-checkout-url.com';
    alert("Simulasi Checkout: Anda akan diarahkan ke halaman pembayaran. Event 'InitiateCheckout' telah dikirim ke Facebook.");
  };

  return (
    <section id="pricing" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="max-w-3xl mx-auto bg-gradient-to-br from-brand-dark-secondary to-brand-dark rounded-2xl p-8 md:p-12 text-center border border-brand-blue/50 shadow-2xl shadow-brand-blue/10"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-light">
            Ambil Jalan Pintas Lo Sekarang.
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Investasi sekali untuk skill seumur hidup. Jangan sampai keduluan teman atau kompetitor lo.
          </p>
          
          <div className="my-8">
            <p className="text-lg text-brand-gray">Harga Normal: <span className="line-through">Rp 330.000</span></p>
            <p className="text-5xl sm:text-6xl font-extrabold text-brand-yellow my-2">Rp 99.000</p>
            <p className="text-lg font-bold text-brand-light">Hanya untuk hari ini!</p>
          </div>

          <div className="my-8 bg-brand-dark rounded-lg p-4 max-w-sm mx-auto">
            <p className="text-sm text-brand-gray mb-2">Diskon 70% Berakhir Dalam:</p>
            <div className="flex justify-center space-x-4 text-brand-light">
              <div className="text-center">
                <div className="text-3xl font-bold bg-brand-dark-secondary px-2 rounded">{formatTime(timeLeft.hours)}</div>
                <div className="text-xs mt-1">Jam</div>
              </div>
              <div className="text-3xl font-bold">:</div>
              <div className="text-center">
                <div className="text-3xl font-bold bg-brand-dark-secondary px-2 rounded">{formatTime(timeLeft.minutes)}</div>
                <div className="text-xs mt-1">Menit</div>
              </div>
              <div className="text-3xl font-bold">:</div>
              <div className="text-center">
                <div className="text-3xl font-bold bg-brand-dark-secondary px-2 rounded">{formatTime(timeLeft.seconds)}</div>
                <div className="text-xs mt-1">Detik</div>
              </div>
            </div>
          </div>

          <a
            href="#"
            onClick={handlePurchaseClick}
            className="w-full bg-brand-blue hover:bg-sky-400 text-brand-dark font-bold text-xl py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 button-glow flex items-center justify-center"
          >
            <Zap className="w-6 h-6 mr-3" />
            DAPATKAN AKSES SEKARANG!
          </a>

          <div className="mt-8 flex items-center justify-center text-brand-gray">
            <ShieldCheck className="w-6 h-6 mr-3 text-green-500" />
            <div>
              <p className="font-semibold text-brand-light">Garansi Uang Kembali 100%</p>
              <p className="text-sm">Jika lo gak ngerasa lebih jenius dalam 7 hari, kami kembalikan uang lo, tanpa ditanya.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
