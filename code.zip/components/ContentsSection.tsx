
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Lightbulb } from 'lucide-react';
import { chapters } from '../constants';

interface AccordionItemProps {
  item: {
    id: string;
    title: string;
    description: string;
  };
  expanded: boolean;
  setExpanded: (expanded: boolean) => void;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ item, expanded, setExpanded }) => {
  const isOpen = expanded;

  return (
    <motion.div className="border border-brand-dark-secondary rounded-lg overflow-hidden">
      <motion.header
        initial={false}
        onClick={() => setExpanded(!isOpen)}
        className="flex justify-between items-center p-4 sm:p-6 cursor-pointer bg-brand-dark-secondary hover:bg-gray-800/50 transition-colors"
      >
        <div className="flex items-center space-x-4">
          <span className="text-brand-blue font-bold text-lg">{item.id}</span>
          <h3 className="font-semibold text-brand-light text-md sm:text-lg">{item.title}</h3>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="w-6 h-6 text-brand-gray" />
        </motion.div>
      </motion.header>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.section
            key="content"
            initial="collapsed"
            animate="open"
            exit="collapsed"
            variants={{
              open: { opacity: 1, height: 'auto' },
              collapsed: { opacity: 0, height: 0 },
            }}
            transition={{ duration: 0.4, ease: [0.04, 0.62, 0.23, 0.98] }}
            className="bg-brand-dark"
          >
            <div className="p-4 sm:p-6 text-brand-gray text-sm sm:text-base border-t border-brand-dark-secondary">
              {item.description}
            </div>
          </motion.section>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const ContentsSection: React.FC = () => {
  const [expanded, setExpanded] = useState<false | number>(false);

  return (
    <section id="contents" className="py-20 sm:py-28 bg-brand-dark-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <Lightbulb className="mx-auto h-12 w-12 text-brand-yellow" />
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold text-brand-light">
            Bocoran 23 'Jurus Rahasia' yang Bakal Lo Kuasai
          </h2>
          <p className="mt-4 text-lg text-brand-gray">
            Setiap bab adalah satu 'hack' praktis. Gak ada basa-basi, langsung ke intinya. Ini beberapa di antaranya:
          </p>
        </div>
        <div className="mt-16 max-w-4xl mx-auto space-y-4">
          {chapters.map((chapter, index) => (
            <AccordionItem
              key={chapter.id}
              item={chapter}
              expanded={expanded === index}
              setExpanded={() => setExpanded(expanded === index ? false : index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ContentsSection;
